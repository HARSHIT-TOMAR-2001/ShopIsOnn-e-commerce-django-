from django.shortcuts import render
from .models import Blogpost
from django.http import HttpResponse
# Create your views here.
def index(request):
    blogs=Blogpost.objects.all()

    return render(request,'blog/index.html',{'blogs':blogs})

def blogpost(request,id):
    blog=Blogpost.objects.filter(post_id=id)
    myblog=blog[0];

    return render(request,'blog/blogpost.html',{'myblog':myblog})