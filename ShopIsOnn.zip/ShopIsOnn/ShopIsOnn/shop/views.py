from django.shortcuts import render
from django.http import HttpResponse
from .models import Product,Contact,Order,OrderUpdate
from math import ceil
import json
# from django.views.decorators.csrf import csrf_exempt
# Create your views here.
def searchMatch(query,item):
    if query in item.desc.lower() or query in item.product_name.lower() or query in item.category.lower():
        return True
    else:
        return False

def search(request):
    query=request.GET.get('search')
    allprods=[]
    catprods=Product.objects.values('category','id')
    cats={items['category'] for items in catprods}
    for cat in cats:
        prodtemp=Product.objects.filter(category=cat)
        prod=[item for item in prodtemp if searchMatch(query,item)]
        n = len(prod)
        nslides = n // 4 + ceil((n / 4) - (n // 4))
        if len(prod)!=0:
            allprods.append([prod,range(1,nslides),nslides])
    params={'allprods':allprods,'msg':""}
    print(len(allprods))
    if len(allprods)==0 or len(query)<3:
        params={"msg":"please make sure to enter valid search query"}
    return render(request,'shop/search.html',params)


def index(request):
    # products=Product.objects.all()
    # print(products)
    # n=len(products)
    # nslides=n//4+ceil((n/4)-(n//4))
    # params={'no_of_slides':nslides,'range':range(1,nslides),'product':products}
    # allprods=[[products,range(1,nslides),nslides],
    #           [products,range(1,nslides),nslides]]
    allprods=[]
    catprods=Product.objects.values('category','id')
    cats={items['category'] for items in catprods}
    for cat in cats:
        prod=Product.objects.filter(category=cat)
        n = len(prod)
        nslides = n // 4 + ceil((n / 4) - (n // 4))
        allprods.append([prod,range(1,nslides),nslides])
    params={'allprods':allprods}
    return render(request,'shop/index.html',params)


def about(request):
    return render(request,'shop/about.html')


def contact(request):
    thank=False
    if request.method =='POST':
        print(request)
        name=request.POST.get('name','')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        desc = request.POST.get('desc', '')
        # print(name,email,phone,desc)
        thank=True;
        contact=Contact(name=name,email=email,phone=phone,desc=desc)
        contact.save()
    return render(request,'shop/contact.html',{'thank':thank})


def tracker(request):
    if request.method=='POST':
        orderid=request.POST.get('orderid','')
        email=request.POST.get('email', '')
        try:
            order=Order.objects.filter(order_id=orderid,email=email)
            if len(order)>0:
                update=OrderUpdate.objects.filter(order_id=orderid)
                updates=[]
                for item in update:
                    updates.append({'text':item.update_desc,'time':item.timestamp})
                    response=json.dumps([updates,order[0].items_json],default=str)
                return  HttpResponse(response)
            else:
                return HttpResponse('{}')
        except Exception as e:
            return HttpResponse('{}')

    return render(request,'shop/tracker.html')


def productview(request,myid):
    #fetch the product using the id!
    product=Product.objects.filter(id=myid)
    return render(request,'shop/prodview.html',{'product':product[0]})


def checkout(request):
    if request.method =='POST':
        print(request)
        items_json = request.POST.get('itemsJson', '')
        name=request.POST.get('name','')
        amount=request.POST.get('amount','')
        email = request.POST.get('email', '')
        address = request.POST.get('address1', '') +","+ request.POST.get('address2', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        zip_code = request.POST.get('zip_code', '')
        phone = request.POST.get('phone', '')
        # print(name,email,address,city,state,zip_code,phone)
        order=Order(items_json=items_json,name=name,amount=amount,email=email,address=address,city=city,state=state,zip_code=zip_code,phone=phone)
        order.save()
        id=order.order_id
        thank=True
        update=OrderUpdate(order_id=id,update_desc='Your Order Has Been Placed!')
        update.save()
        return render(request,'shop/checkout.html',{'thank':thank,'id':id})
    return render(request,'shop/checkout.html')


# @csrf_exempt
# def handlerequest(request):
#     #paytm post request here.
#     pass

